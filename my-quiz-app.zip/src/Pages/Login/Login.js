import React from 'react';
import "./Login.css"
const Login = () => {
    return (
        <div>

        </div>
    );
};

export default Login;