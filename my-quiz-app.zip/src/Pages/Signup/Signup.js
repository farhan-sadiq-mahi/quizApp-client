import React from 'react';
import "./Signup.css"

const Signup = () => {
    return (
        <div>

        </div>
    );
};

export default Signup;